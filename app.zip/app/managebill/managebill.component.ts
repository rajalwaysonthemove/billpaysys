import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-managebill',
  templateUrl: './managebill.component.html',
  styleUrls: ['./managebill.component.css']
})
export class ManagebillComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
