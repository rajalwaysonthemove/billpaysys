import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-billpay',
  templateUrl: './billpay.component.html',
  styleUrls: ['./billpay.component.css']
})
export class BillpayComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
